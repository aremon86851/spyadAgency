/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  imageOptimization: false,
};

module.exports = nextConfig;
